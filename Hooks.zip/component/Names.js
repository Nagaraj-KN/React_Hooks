import React, { useState} from 'react'

export default function Names() {


     const [name, setName]=useState('Tony')
    return (
        <div>
            <h1>{name}</h1>
            <button onClick={()=>setName('Rony')}>Click</button>
        </div>
    )
}
