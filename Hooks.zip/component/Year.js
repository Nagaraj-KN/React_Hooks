import React,{ useState } from 'react'

export default function Year() {
    const[year, setYear]=useState(2021)
    return (

     
        <div>
            <h1>{year}</h1>
            <button onClick={()=>setYear(year+1)}>Click</button>
        </div>
    )
}
