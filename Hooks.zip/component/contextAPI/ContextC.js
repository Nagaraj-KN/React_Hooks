import React, { Component } from 'react'
import ContextE from './ContextE'

export class ContextC extends Component {
    render() {
        return (
            <div>
                <ContextE></ContextE>
            </div>
        )
    }
}

export default ContextC
