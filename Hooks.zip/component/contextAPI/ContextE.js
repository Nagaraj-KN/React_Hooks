import React, { Component } from 'react'
import ContextF from './ContextF'

export class ContextE extends Component {
    render() {
        return (
            <div>
                <ContextF></ContextF>
            </div>
        )
    }
}

export default ContextE
