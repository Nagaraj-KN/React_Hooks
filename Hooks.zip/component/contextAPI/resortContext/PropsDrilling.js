import React, { Component } from 'react'

//additional child component

const Trail =props=>{
    <div>
        {props.name}
    </div>
}


//Child component-1

const Lift =props=>{
    <div>
        <Trail name={props.name}/>
    </div>
}



//Parent component
export default class Resort
extends Component {
    state={
        name:"Hulivana"
    }
    render() {
        return (
            <div>
                <Lift name={this.props.name}/>
            </div>
        )
    }
}
