import React, { Component } from 'react'

const Mycontext = React.createContext()


class Provider extends React.Component{
    state= {
        name:"Farmer Son",
        status:"Open"
        
    }
    render(){
        return(
            <Mycontext.Provider value={{state:this.state, changeStatus:()=>this.setState({
                status:"closed"
            })}}>
                {this.props.children}

            </Mycontext.Provider>

            
        )
    }
}

const Trail = props => (
<>
    <Mycontext.Consumer>
        {(context)=>(
            <div>
        <p>The resort name is:{context.state.name}</p>
        <p>This status of resort is:{context.state.status}</p>
        <button onClick={context.changeStatus}>Close Resort</button>
        </div>
        )}

    </Mycontext.Consumer>
    </>
)


const Lift = props =>(

        <div>
        <Trail />
    </div>
)


export default class ResortState extends Component {
    render() {
        return (
            <Provider>
            <div>
            <Lift/>
            </div>
            </Provider>
        )
    }
}
