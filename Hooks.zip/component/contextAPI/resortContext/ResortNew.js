import React from 'react'


const MyContext = React.createContext();


 class Provider extends React.Component {
    state = {
        name: "Hulivana"
    }


    render() {
        return (

   < MyContext.Provider value = {{ state: this.state }}>
        { this.props.children }
  </MyContext.Provider >

        )
    }

}


const Trail = props => (
    <div>
        <MyContext.Consumer>
            {(context) => (
                <p>This is the context value: {context.state.name}</p>
            )}
        </MyContext.Consumer>

    </div>
)
const Lift = props => (
    <div>
        <Trail></Trail>
    </div>

)




export default class ResortNew extends React.Component {
    render() {
        return (
            <Provider>
                <div>
                    <Lift></Lift>
                </div>
            </Provider>
        )
    }
}
