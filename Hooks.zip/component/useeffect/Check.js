import React, { useEffect, useState } from 'react'

export default function Checked() {
const [Checked, setChecked]=useState(false);

useEffect(()=>{
    alert(`checked:${Checked.toString()}`)
})

    return (
        <div>
            <input type='checkbox' value={Checked} onChange={()=>setChecked(Checked =>!Checked)}/>

            {Checked ? "checked" :"unchecked"}

        </div>
    )
}
