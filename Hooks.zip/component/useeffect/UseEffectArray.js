import React, { useEffect,useState } from 'react'

export default function UseEffectArray() {

     const [val, setVal1]= useState("");
     const [val2,setVal2]= useState("");

     useEffect(()=>{
         console.log(`field1:${val}`);
     },[val]);

     useEffect(()=>{
         console.log(`field2:${val2}`);
     },[val2]);
    return (
        <div>
            <label>First Phrase:
                <input value={val} onChange={e=>setVal1(e.target.value)}></input>
            </label>

            <br>
            
            </br>
            <label>Second Phrase
                <input value={val2} onChange={e=>setVal2(e.target.value)}></input>
            </label>
        </div>
    )
}
