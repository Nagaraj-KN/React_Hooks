
import './App.css';
// 
// import Names from './component/Names'
// import UseStateObject from './component/UseStateObject'
// 
// import Year from './component/Year'
// 
// import UseStateArray from './component/UseStateArray'
// 
// import HookEffectOne from './component/useeffect/HookEffectOne'
// 
// import Checked from './component/useeffect/Check'
// 
// import UseEffectArray from './component/useeffect/UseEffectArray'
// 
// import Reducer from './component/usereducer/Reducer'

// import DynamicTable from './assaignemnts/Table'

// import DynamicTable from './assaignemnts/Example'


// import Assaignments1 from './assaignemnts/Example'
// import ContextC from './component/contextAPI/ContextC';
// import { UserProvider } from './component/contextAPI/UserContext';
// 
// import Resort from './component/contextAPI/resortContext/PropsDrilling'

import ResortNew from './component/contextAPI/resortContext/ResortNew'

import ResortState from './component/contextAPI/resortContext/ResortState'


function App() {
  return (
    <div className="App">

  {/* <Names></Names> */}
  {/* <hr></hr> */}

      {/* <UseStateObject></UseStateObject> */}

      {/* <hr></hr> */}

      {/* <Year></Year> */}

      {/* <hr></hr> */}

      {/* <UseStateArray></UseStateArray> */}

      {/* <hr></hr> */}


      {/* <HookEffectOne></HookEffectOne> */}
{/*       */}


{/* <Checked></Checked> */}
{/*  */}
{/* <UseEffectArray></UseEffectArray> */}
{/*  */}
{/*  */}
{/* <Reducer> */}
{/* </Reducer> */}
{/* <DynamicTable></DynamicTable> */}
{/* <Assaignments1></Assaignments1> */}

----Context APi------

{/* <UserProvider value='sandy'> */}
{/* <ContextC></ContextC> */}
{/* </UserProvider> */}

{/* <Resort></Resort> */}

{/* <ResortNew></ResortNew> */}
<ResortState />
    </div>
  );
}

export default App;
